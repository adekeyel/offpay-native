import React from 'react';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { Text } from 'react-native';
import { colors } from '../theme/colors';

import HomeScreen from '../screens/home/HomeScreen';
import NotificationsScreen from '../screens/home/NotificationsScreen';
import VtuCategoryScreen from '../screens/vtu/VtuCategoryScreen';
import SendToUserChooserScreen from '../screens/home/SendToUserChooserScreen';
import SendToWalletScreen from '../screens/home/SendToWalletScreen';
import SendOfflineScreen from '../screens/home/SendOfflineScreen';
import ReceiveOfflineScreen from '../screens/home/ReceiveOfflineScreen';
import BankTransferScreen from '../screens/home/BankTransferScreen';
import AddMoneyScreen from '../screens/home/AddMoneyScreen';

import CardScreen from '../screens/card/CardScreen';

import FinanceScreen from '../screens/finance/FinanceScreen';
import WealthProductScreen from '../screens/finance/WealthProductScreen';

import RewardsScreen from '../screens/rewards/RewardsScreen';

import MeScreen from '../screens/me/MeScreen';
import ProfileScreen from '../screens/me/ProfileScreen';
import StatementScreen from '../screens/me/StatementScreen';
import TransactionHistoryScreen from '../screens/me/TransactionHistoryScreen';
import TransactionDetailScreen from '../screens/me/TransactionDetailScreen';
import SettingsSecurityScreen from '../screens/me/SettingsSecurityScreen';
import BiometricSetupScreen from '../screens/me/BiometricSetupScreen';
import TierUpgradeScreen from '../screens/me/TierUpgradeScreen';
import SupportScreen from '../screens/me/SupportScreen';
import SupportTicketThreadScreen from '../screens/me/SupportTicketThreadScreen';
import AboutScreen from '../screens/legal/AboutScreen';
import TermsScreen from '../screens/legal/TermsScreen';
import PrivacyPolicyScreen from '../screens/legal/PrivacyPolicyScreen';
import ComplianceScreen from '../screens/legal/ComplianceScreen';
import type { Transaction } from '../types/api';

export type HomeStackParamList = {
  HomeMain: undefined;
  Notifications: undefined;
  VtuCategory: { category: 'airtime' | 'data' | 'cable' | 'electricity' };
  SendToUserChooser: undefined;
  SendToWallet: undefined;
  SendOffline: undefined;
  ReceiveOffline: undefined;
  BankTransfer: undefined;
  AddMoney: undefined;
};
export type FinanceStackParamList = {
  FinanceMain: undefined;
  WealthProduct: { productId: string };
};
export type MeStackParamList = {
  MeMain: undefined;
  Profile: undefined;
  Statement: undefined;
  TransactionHistory: undefined;
  TransactionDetail: { transaction: Transaction };
  SettingsSecurity: undefined;
  BiometricSetup: undefined;
  TierUpgrade: undefined;
  Support: undefined;
  SupportTicketThread: { ticketId: string };
  About: undefined;
  Terms: undefined;
  PrivacyPolicy: undefined;
  Compliance: undefined;
};

const HomeStackNav = createNativeStackNavigator<HomeStackParamList>();
function HomeStack() {
  return (
    <HomeStackNav.Navigator screenOptions={{ headerShown: false }}>
      <HomeStackNav.Screen name="HomeMain" component={HomeScreen} />
      <HomeStackNav.Screen name="Notifications" component={NotificationsScreen} options={{ headerShown: true, title: 'Notifications' }} />
      <HomeStackNav.Screen name="VtuCategory" component={VtuCategoryScreen} options={{ headerShown: true, title: '' }} />
      <HomeStackNav.Screen name="SendToUserChooser" component={SendToUserChooserScreen} options={{ headerShown: true, title: 'To OffPay User' }} />
      <HomeStackNav.Screen name="SendToWallet" component={SendToWalletScreen} options={{ headerShown: true, title: 'Send online' }} />
      <HomeStackNav.Screen name="SendOffline" component={SendOfflineScreen} options={{ headerShown: true, title: 'Send (offline)' }} />
      <HomeStackNav.Screen name="ReceiveOffline" component={ReceiveOfflineScreen} options={{ headerShown: true, title: 'Receive (offline)' }} />
      <HomeStackNav.Screen name="BankTransfer" component={BankTransferScreen} options={{ headerShown: true, title: 'Send to bank' }} />
      <HomeStackNav.Screen name="AddMoney" component={AddMoneyScreen} options={{ headerShown: true, title: 'Add Money' }} />
    </HomeStackNav.Navigator>
  );
}

const CardStackNav = createNativeStackNavigator();
function CardStack() {
  return (
    <CardStackNav.Navigator screenOptions={{ headerShown: false }}>
      <CardStackNav.Screen name="CardMain" component={CardScreen} />
    </CardStackNav.Navigator>
  );
}

const FinanceStackNav = createNativeStackNavigator<FinanceStackParamList>();
function FinanceStack() {
  return (
    <FinanceStackNav.Navigator screenOptions={{ headerShown: false }}>
      <FinanceStackNav.Screen name="FinanceMain" component={FinanceScreen} />
      <FinanceStackNav.Screen name="WealthProduct" component={WealthProductScreen} options={{ headerShown: true, title: '' }} />
    </FinanceStackNav.Navigator>
  );
}

const RewardsStackNav = createNativeStackNavigator();
function RewardsStack() {
  return (
    <RewardsStackNav.Navigator screenOptions={{ headerShown: false }}>
      <RewardsStackNav.Screen name="RewardsMain" component={RewardsScreen} />
    </RewardsStackNav.Navigator>
  );
}

const MeStackNav = createNativeStackNavigator<MeStackParamList>();
function MeStack() {
  return (
    <MeStackNav.Navigator screenOptions={{ headerShown: false }}>
      <MeStackNav.Screen name="MeMain" component={MeScreen} />
      <MeStackNav.Screen name="Profile" component={ProfileScreen} options={{ headerShown: true, title: 'My Profile' }} />
      <MeStackNav.Screen name="Statement" component={StatementScreen} options={{ headerShown: true, title: 'Statement of Account' }} />
      <MeStackNav.Screen name="TransactionHistory" component={TransactionHistoryScreen} options={{ headerShown: true, title: 'Transactions' }} />
      <MeStackNav.Screen name="TransactionDetail" component={TransactionDetailScreen} options={{ headerShown: true, title: 'Transaction Details' }} />
      <MeStackNav.Screen name="SettingsSecurity" component={SettingsSecurityScreen} options={{ headerShown: true, title: 'Settings & Security' }} />
      <MeStackNav.Screen name="BiometricSetup" component={BiometricSetupScreen} options={{ headerShown: true, title: 'Set up biometrics' }} />
      <MeStackNav.Screen name="TierUpgrade" component={TierUpgradeScreen} options={{ headerShown: true, title: 'Upgrade Tier' }} />
      <MeStackNav.Screen name="Support" component={SupportScreen} options={{ headerShown: true, title: 'Support' }} />
      <MeStackNav.Screen name="SupportTicketThread" component={SupportTicketThreadScreen} options={{ headerShown: true, title: 'Conversation' }} />
      <MeStackNav.Screen name="About" component={AboutScreen} options={{ headerShown: true, title: 'About OffPay' }} />
      <MeStackNav.Screen name="Terms" component={TermsScreen} options={{ headerShown: true, title: 'Terms of Service' }} />
      <MeStackNav.Screen name="PrivacyPolicy" component={PrivacyPolicyScreen} options={{ headerShown: true, title: 'Privacy Policy' }} />
      <MeStackNav.Screen name="Compliance" component={ComplianceScreen} options={{ headerShown: true, title: 'Regulatory & Complaints' }} />
    </MeStackNav.Navigator>
  );
}

const Tab = createBottomTabNavigator();

function TabIcon({ symbol, focused }: { symbol: string; focused: boolean }) {
  return <Text style={{ fontSize: 20, opacity: focused ? 1 : 0.5 }}>{symbol}</Text>;
}

export default function MainTabNavigator() {
  return (
    <Tab.Navigator
      screenOptions={{
        headerShown: false,
        tabBarActiveTintColor: colors.unlock,
        tabBarInactiveTintColor: colors.slate,
        tabBarStyle: { borderTopColor: colors.line },
      }}
    >
      <Tab.Screen name="Home" component={HomeStack} options={{ tabBarIcon: ({ focused }) => <TabIcon symbol="⌂" focused={focused} /> }} />
      <Tab.Screen name="Card" component={CardStack} options={{ tabBarIcon: ({ focused }) => <TabIcon symbol="▭" focused={focused} /> }} />
      <Tab.Screen name="Finance" component={FinanceStack} options={{ tabBarIcon: ({ focused }) => <TabIcon symbol="◈" focused={focused} /> }} />
      <Tab.Screen name="Rewards" component={RewardsStack} options={{ tabBarIcon: ({ focused }) => <TabIcon symbol="✦" focused={focused} /> }} />
      <Tab.Screen
        name="Me"
        component={MeStack}
        options={{ tabBarIcon: ({ focused }) => <TabIcon symbol="●" focused={focused} /> }}
        listeners={({ navigation }) => ({
          tabPress: () => {
            // Without this, tapping the "Me" tab shows whatever screen was
            // last open in it (e.g. Settings & Security, if you got there
            // via the dashboard gear icon shortcut) instead of the main Me
            // screen — which looks like Me/Tiers/Statement/etc. vanished.
            navigation.navigate('Me', { screen: 'MeMain' });
          },
        })}
      />
    </Tab.Navigator>
  );
}
